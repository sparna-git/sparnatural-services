import axios from "axios";
import {
  ReconcileOutput,
  ReconcileServiceIfc,
  ReconcileInput,
  ReconcileResult,
  ManifestType,
} from "../interfaces/ReconcileServiceIfc";
import { inject, injectable } from "tsyringe";
import { LuceneGraphDBReconcileServiceConfig } from "../../../config/ProjectConfig";
import {
  collectUnresolvedLabels,
  buildLabelToUriMap,
  injectResolvedUris,
} from "../helpers/UriReconciliationHelperV13";
import { getSHACLConfig } from "../../../config/SCHACL";

type CacheEntry = { results: ReconcileResult[]; lastAccessed: Date };
type SearchResult = { uri: string; label: string };

/**
 * Service de réconciliation basé sur le connecteur Lucene de GraphDB.
 */
@injectable({ token: "LuceneGraphDBReconcileService" })
export class LuceneGraphDBReconcileService implements ReconcileServiceIfc {
  public static DEFAULT_MAX_RESULTS = 10;
  public static DEFAULT_CACHE_SIZE = 1000;
  public static DEFAULT_INDEX_NAME = "MedicamentIndexThird";

  private memoryCache: Record<string, CacheEntry> = {};
  private projectId: string;
  private sparqlEndpoint: string;
  private maxResults: number;
  private cacheSize: number;
  private luceneIndexName: string;

  constructor(
    @inject("project.id") projectId?: string,
    @inject("project.sparqlEndpoint") sparqlEndpoint?: string,
    @inject("reconciliation.config")
    reconciliationConfig?: LuceneGraphDBReconcileServiceConfig,
  ) {
    this.projectId = projectId || "";
    this.sparqlEndpoint = sparqlEndpoint || "";
    this.maxResults =
      reconciliationConfig?.maxResults ||
      LuceneGraphDBReconcileService.DEFAULT_MAX_RESULTS;
    this.cacheSize =
      reconciliationConfig?.cacheSize ||
      LuceneGraphDBReconcileService.DEFAULT_CACHE_SIZE;
    this.luceneIndexName =
      reconciliationConfig?.luceneIndexName ||
      LuceneGraphDBReconcileService.DEFAULT_INDEX_NAME;
  }

  // ─── Manifest ───────────────────────────────────────────────

  buildManifest(): Promise<ManifestType> {
    return Promise.resolve({
      versions: ["0.2"],
      name: `Reconciliation Lucene ${this.projectId}`,
      identifierSpace: `https://services.sparnatural.eu/projects/${this.projectId}`,
      schemaSpace: `https://services.sparnatural.eu/projects/${this.projectId}`,
      view: { url: "{{id}}" },
      defaultTypes: [],
      types: [],
      features: {
        "property-search": false,
        "type-search": false,
        preview: false,
        suggest: false,
      },
    });
  }

  // ─── Reconciliation principale ──────────────────────────────

  async reconcileQueries(
    queries: ReconcileInput,
    includeTypes: boolean,
  ): Promise<ReconcileOutput> {
    const responsePayload: ReconcileOutput = {};

    // Dédupliquer par label normalisé
    const uniqueMap = new Map<string, [string, any]>();
    for (const [key, qobj] of Object.entries(queries)) {
      const normalized = qobj.query.trim().toLowerCase();
      if (!uniqueMap.has(normalized)) {
        uniqueMap.set(normalized, [key, qobj]);
      }
    }

    for (const [key, qobj] of uniqueMap.values()) {
      const name = qobj.query.trim();
      const cacheKey = this.buildCacheKey(name, qobj.type, includeTypes);

      if (this.checkCache(cacheKey, includeTypes)) {
        this.memoryCache[cacheKey].lastAccessed = new Date();
        responsePayload[key] = { result: this.memoryCache[cacheKey].results };
        this.logResult(name, this.memoryCache[cacheKey].results, "cache");
        continue;
      }

      // Le rdfType Sparnatural (type config, ex: "https://.../sparnatural-config.ttl#Voie")
      const configTypeUri = qobj.type as string | undefined;

      console.log(
        `\n[graphdb-recon] ═══ Réconciliation : "${name}" | type: ${configTypeUri ?? "aucun"} ═══`,
      );
      console.log(
        `[graphdb-recon] Recherche Lucene (index: ${this.luceneIndexName})`,
      );

      const searchResults: SearchResult[] = await this.searchLucene(
        name,
        configTypeUri,
      );
      const source = "lucene";

      console.log(
        `[graphdb-recon] Lucene → ${searchResults.length} résultat(s) :`,
        searchResults.map((r) => `"${r.label}" (${r.uri.split("/").pop()})`),
      );

      const results = this.formatResults(searchResults, name);
      this.updateCache(cacheKey, results);
      responsePayload[key] = { result: results };
      this.logResult(name, results, source);
    }

    return responsePayload;
  }

  // ─── Résolution des URI_NOT_FOUND ──────────────────────────

  async resolveQueryUris(parsedQuery: any): Promise<any> {
    const labelsToResolve = collectUnresolvedLabels(parsedQuery);

    if (Object.keys(labelsToResolve).length === 0) {
      console.log("[graphdb-recon] No URI_NOT_FOUND to resolve.");
      return parsedQuery;
    }

    console.log(
      `[graphdb-recon] Resolving ${Object.keys(labelsToResolve).length} label(s):`,
      Object.values(labelsToResolve).map((l) => l.query),
    );

    const queries = LuceneGraphDBReconcileService.parseQueries(labelsToResolve);
    const uriRes = await this.reconcileQueries(queries, false);
    const labelToUri = buildLabelToUriMap(labelsToResolve, uriRes);
    injectResolvedUris(parsedQuery, labelToUri);

    return parsedQuery;
  }

  // ─── Étape 1 : Recherche Lucene ─────────────────────────────

  /**
   * Recherche dans l'index Lucene avec traversée de prédicats.
   *
   * Quand configTypeUri est fourni, la requête utilise un UNION pour :
   *   1. Retourner directement le résultat Lucene s'il est du bon type
   *      (?luceneResult a <configTypeUri>)
   *   2. OU traverser un niveau de prédicats pour trouver une entité liée
   *      du bon type (?luceneResult ?p ?entity . ?entity a <configTypeUri>)
   *      → ex. SpecialitePharmaceutique → med:voie → Voie
   *
   * expandSparql traduit le type config Sparnatural → type réel dans les données.
   * Si le type n'est pas dans l'index ET sans entités liées → retourne [] → fallback SPARQL.
   */
  private async searchLucene(
    name: string,
    configTypeUri?: string,
  ): Promise<SearchResult[]> {
    const escapedName = name.replace(/"/g, '\\"');

    let sparql: string;

    if (configTypeUri) {
      sparql = `
        PREFIX : <http://www.ontotext.com/connectors/lucene#>
        PREFIX inst: <http://www.ontotext.com/connectors/lucene/instance#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX med: <http://data.esante.gouv.fr/ansm/medicament/>

        SELECT ?entity (SAMPLE(?lbl) AS ?label) WHERE {
            {
                SELECT ?entity (MIN(STRLEN(?l)) AS ?minLen) WHERE {
                    ?search a inst:${this.luceneIndexName} .
                    ?search :query "${escapedName}" .
                    ?search :entities ?luceneResult .
                    {
                        {
                            ?luceneResult a <${configTypeUri}> .
                            BIND(?luceneResult AS ?entity)
                        } UNION {
                            ?luceneResult ?p ?entity .
                            ?entity a <${configTypeUri}> .
                        }
                        ?entity rdfs:label ?l .
                        FILTER(LANG(?l) = "fr" || LANG(?l) = "")
                    } UNION {
                        ?luceneResult med:classificationATC ?entity .
                        ?entity a <${configTypeUri}> .
                        ?luceneResult med:codeATC ?code .
                        ?luceneResult med:libelleATC ?libelleAtc .
                        BIND(CONCAT(STR(?code), " - ", STR(?libelleAtc)) AS ?l)
                    }
                }
                GROUP BY ?entity
            }
            {
                ?entity rdfs:label ?lbl .
                FILTER(LANG(?lbl) = "fr" || LANG(?lbl) = "")
                FILTER(STRLEN(?lbl) = ?minLen)
            } UNION {
                ?spec med:classificationATC ?entity .
                ?spec med:codeATC ?code .
                ?spec med:libelleATC ?libelleAtc .
                BIND(CONCAT(STR(?code), " - ", STR(?libelleAtc)) AS ?lbl)
                FILTER(STRLEN(?lbl) = ?minLen)
            }
        }
        GROUP BY ?entity ?minLen
        ORDER BY ?minLen
        LIMIT ${this.maxResults}
      `;

      // expandSparql traduit "?entity a <configTypeUri>" → "?entity a <dataTypeUri>"
      try {
        const { postProcessor } = await getSHACLConfig(this.projectId);
        sparql = postProcessor.expandSparql(sparql, {});
        console.log(`[graphdb-recon] Lucene SPARQL après expand:\n${sparql}`);
      } catch (_err) {
        console.log(
          `[graphdb-recon] SHACL non configuré → requête Lucene avec configTypeUri tel quel`,
        );
        console.log(`[graphdb-recon] Lucene SPARQL (sans expand):\n${sparql}`);
      }
    } else {
      // Sans type : requête Lucene simple
      console.log(
        `[graphdb-recon] Aucun type fourni → requête Lucene sans filtre de type`,
      );
      sparql = `
        PREFIX : <http://www.ontotext.com/connectors/lucene#>
        PREFIX inst: <http://www.ontotext.com/connectors/lucene/instance#>
        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        PREFIX med: <http://data.esante.gouv.fr/ansm/medicament/>

        SELECT ?entity (SAMPLE(?lbl) AS ?label) WHERE {
            {
                SELECT ?entity (MIN(STRLEN(?l)) AS ?minLen) WHERE {
                    ?search a inst:${this.luceneIndexName} .
                    ?search :query "${escapedName}" .
                    ?search :entities ?luceneResult .
                    {
                        BIND(?luceneResult AS ?entity)
                        ?entity rdfs:label ?l .
                        FILTER(LANG(?l) = "fr" || LANG(?l) = "")
                    } UNION {
                        ?luceneResult med:classificationATC ?entity .
                        ?luceneResult med:codeATC ?code .
                        ?luceneResult med:libelleATC ?libelleAtc .
                        BIND(CONCAT(STR(?code), " - ", STR(?libelleAtc)) AS ?l)
                    }
                }
                GROUP BY ?entity
            }
            {
                ?entity rdfs:label ?lbl .
                FILTER(LANG(?lbl) = "fr" || LANG(?lbl) = "")
                FILTER(STRLEN(?lbl) = ?minLen)
            } UNION {
                ?spec med:classificationATC ?entity .
                ?spec med:codeATC ?code .
                ?spec med:libelleATC ?libelleAtc .
                BIND(CONCAT(STR(?code), " - ", STR(?libelleAtc)) AS ?lbl)
                FILTER(STRLEN(?lbl) = ?minLen)
            }
        }
        GROUP BY ?entity ?minLen
        ORDER BY ?minLen
        LIMIT ${this.maxResults}
      `;
      console.log(`[graphdb-recon] Lucene SPARQL (sans type):\n${sparql}`);
    }

    try {
      const response = await axios.get(
        `${this.sparqlEndpoint}?query=${encodeURIComponent(sparql)}&format=json`,
        { timeout: 60000, family: 4 },
      );
      return response.data.results.bindings.map((b: any) => ({
        uri: b.entity.value,
        label: b.label?.value || name,
      }));
    } catch (err) {
      console.error(`[graphdb-recon] Lucene error for "${name}":`, err);
      return [];
    }
  }

  // ─── Formatage des résultats ────────────────────────────────

  formatResults(
    searchResults: SearchResult[],
    fallbackName: string,
  ): ReconcileResult[] {
    if (searchResults.length === 0) return [];

    return searchResults.map((r, index) => ({
      id: r.uri,
      name: r.label || fallbackName,
      score: index === 0 ? 100 : Math.max(100 - index, 1),
      match: index === 0,
    }));
  }

  // ─── Cache ──────────────────────────────────────────────────

  private buildCacheKey(
    name: string,
    type?: string,
    includeTypes?: boolean,
  ): string {
    return encodeURIComponent(
      name.toLowerCase() +
        (type ? `|${type}` : "") +
        (includeTypes ? "|openrefine" : "|simple"),
    );
  }

  private checkCache(cacheKey: string, includeTypes: boolean): boolean {
    const entry = this.memoryCache[cacheKey];
    if (!entry) return false;
    if (includeTypes && !entry.results[0]?.type) return false;
    return true;
  }

  updateCache(key: string, results: ReconcileResult[]) {
    this.memoryCache[key] = { results, lastAccessed: new Date() };
    const keys = Object.keys(this.memoryCache);
    if (keys.length > this.cacheSize) {
      const oldestKey = keys.reduce((a, b) =>
        this.memoryCache[a].lastAccessed < this.memoryCache[b].lastAccessed
          ? a
          : b,
      );
      delete this.memoryCache[oldestKey];
      console.log(`[cache] LRU: suppression "${oldestKey}"`);
    }
  }

  // ─── Utils ──────────────────────────────────────────────────

  private logResult(
    name: string,
    results: ReconcileResult[],
    source: string,
  ): void {
    console.log(
      results.length > 0
        ? `[graphdb-recon] "${name}" → "${results[0].id}" label:"${results[0].name}" (${source})`
        : `[graphdb-recon] "${name}" → aucun résultat (${source})`,
    );
  }

  static parseQueries(body: any): ReconcileInput {
    if (!body) throw new Error("Empty body");
    if (body.queries) {
      return typeof body.queries === "string"
        ? JSON.parse(body.queries)
        : body.queries;
    }
    if (typeof body === "object" && !Array.isArray(body)) {
      return body;
    }
    throw new Error("Invalid queries format");
  }
}
